﻿namespace EscolheLivros.Models
{
    public class Livro
    {
        public long Id { get; set; }

        public string? Title { get; set;}

        public long Preco { get; set; }

        public long ClientId { get; set; }
    }
}