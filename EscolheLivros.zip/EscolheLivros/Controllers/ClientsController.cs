﻿using EscolheLivros.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using RestSharp;

namespace EscolheLivros.Controllers
{
    public class ClientsController : Controller
    {
        private string _clientApi;

        public ClientsController(IConfiguration configuration)
        {
            _clientApi = configuration["Apis:ClientApi"];
        }

        public IActionResult Index()
        {
            List<Client> clients = new List<Client>();

            if (_clientApi == null)
                return NotFound();

            RestResponse response = ExecuteRequest(_clientApi, null, Method.Get);

            if (response.IsSuccessStatusCode)
            {
                List<Client>? clientsJson = JsonConvert.
                    DeserializeObject<List<Client>>(response.Content ?? "");

                if (clientsJson != null)
                {
                    foreach (Client client in clientsJson)
                    {
                        clients.Add(client);
                    }
                }
            }

            return View("ClientIndex", clients);
        }

        public IActionResult Details(long? id)
        {
            if (id == null || _clientApi == null)
                return NotFound();

            Client? client = null;

            var response = ExecuteRequest($"{_clientApi}{id}", null, Method.Get);

            if (response.IsSuccessStatusCode)
            {
                Client? clientJson = JsonConvert.
                    DeserializeObject<Client>(response.Content ?? "");

                client = clientJson;
            }

            if (client == null)
                return NotFound();

            return View("ClientDetails", client);
        }

        public IActionResult Create()
        {
            return View("ClientCreate");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind("Id,Name,Age")] Client client)
        {
            if (ModelState.IsValid)
            {
                object data = new
                {
                    name = client.Name,
                    age = client.Age
                };

                RestResponse response = ExecuteRequest(_clientApi, data, Method.Post);
                
                if (response.IsSuccessStatusCode)
                    return RedirectToAction(nameof(Index));
            }

            return View("ClientCreate", client);
        }

        public IActionResult Edit(long? id)
        {
            if (id == null || _clientApi == null)
                return NotFound();

            Client? client = null;

            var response = ExecuteRequest($"{_clientApi}{id}", null, Method.Get);

            if (response.IsSuccessStatusCode)
            {
                Client? clientJson = JsonConvert.
                    DeserializeObject<Client>(response.Content ?? "");

                client = clientJson;
            }

            if (client == null)
                return NotFound();

            return View("ClientEdit", client);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(long id, [Bind("Id,Name,Age")] Client client)
        {
            if (id != client.Id)
                return NotFound();

            if (ModelState.IsValid) 
            {
                try
                {
                    object data = new
                    {
                        id = client.Id,
                        name = client.Name,
                        age = client.Age
                    };

                    RestResponse response = ExecuteRequest($"{_clientApi}{id}", data, Method.Put);

                    if (!response.IsSuccessful)
                        throw new Exception();

                }
                catch (Exception)
                {
                    if (!ClientExists(client.Id))
                        return NotFound();
                    else
                        throw;
                }
                return RedirectToAction(nameof(Index));
            }
            return View("ClientEdit", client);
        }

        private bool ClientExists(long id)
        {
            Client? client = null;

            var response = ExecuteRequest($"{_clientApi}{id}", null, Method.Get);

            if (response.IsSuccessStatusCode)
            {
                Client? clientJson = JsonConvert.
                    DeserializeObject<Client>(response.Content ?? "");

                client = clientJson;
            }

            return client != null;
        }

        private RestResponse ExecuteRequest(string url, object? data, Method method)
        {
            RestClient restClient = new RestClient(url);

            RestRequest request = new RestRequest()
            {
                RequestFormat = DataFormat.Json,
                Method = method
            };

            request.AddHeader("content-type", "application/json");

            if (method == Method.Post || method == Method.Put)
                request.AddBody(data);

            return restClient.Execute(request);
        }
    }
}
