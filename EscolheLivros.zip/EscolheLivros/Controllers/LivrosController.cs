﻿using EscolheLivros.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using RestSharp;

namespace EscolheLivros.Controllers
{
    public class LivrosController : Controller
    {
        private string _livroApi;
        private string _clientApi;

        public LivrosController(IConfiguration configuration)
        {
            _livroApi = configuration["Apis:LivroApi"];
            _clientApi = configuration["Apis:ClientApi"];
        }

        public IActionResult Index()
        {
            List<Livro> Livros = new List<Livro>();

            if (_livroApi == null)
                return NotFound();

            RestResponse response = ExecuteRequest(_livroApi, null, Method.Get);

            if (response.IsSuccessStatusCode)
            {
                List<Livro>? LivrosJson = JsonConvert.
                    DeserializeObject<List<Livro>>(response.Content ?? "");

                if (LivrosJson != null)
                {
                    foreach (Livro Livro in LivrosJson)
                    {
                        Livros.Add(Livro);
                    }
                }
            }

            return View("LivroIndex", Livros);
        }

        public IActionResult Details(long? id)
        {
            if (id == null || _livroApi == null)
                return NotFound();

            Livro? Livro = null;

            var response = ExecuteRequest($"{_livroApi}{id}", null, Method.Get);

            if (response.IsSuccessStatusCode)
            {
                Livro? LivroJson = JsonConvert.
                    DeserializeObject<Livro>(response.Content ?? "");

                Livro = LivroJson;
            }

            if (Livro == null)
                return NotFound();

            return View("LivroDetails", Livro);
        }

        public IActionResult Create(long clientId)
        {
            Livro Livro = new Livro()
            {
                ClientId = clientId
            };

            return View("LivroCreate", Livro);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind("Id,Title,Preco,ClientId")] Livro Livro)
        {
            if (ModelState.IsValid)
            {

                RestResponse clientResponse = ExecuteRequest($"{_clientApi}{Livro.ClientId}", null, Method.Get);

                if (clientResponse.IsSuccessStatusCode)
                {
                    Client? client = JsonConvert.DeserializeObject<Client>(clientResponse.Content ?? string.Empty);

                    if (client != null)
                    {
                        object data = new
                        {
                            title = Livro.Title,
                            preco = Livro.Preco,
                            clientid = Livro.ClientId
                        };

                        RestResponse response = ExecuteRequest(_livroApi, data, Method.Post);

                        if (response.IsSuccessStatusCode)
                            return RedirectToAction(nameof(Index));
                    }
                }
            }

            return View("LivroCreate", Livro);
        }

        public IActionResult Edit(long? id)
        {
            if (id == null || _livroApi == null)
                return NotFound();

            Livro? Livro = null;

            var response = ExecuteRequest($"{_livroApi}{id}", null, Method.Get);

            if (response.IsSuccessStatusCode)
            {
                Livro? LivroJson = JsonConvert.
                    DeserializeObject<Livro>(response.Content ?? "");

                Livro = LivroJson;
            }

            if (Livro == null)
                return NotFound();

            return View("LivroEdit", Livro);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(long id, [Bind("Id,Title,Preco,ClientId")] Livro Livro)
        {
            if (id != Livro.Id)
                return NotFound();

            if (ModelState.IsValid)
            {
                try
                {
                    RestResponse clientResponse = ExecuteRequest($"{_clientApi}{Livro.ClientId}", null, Method.Get);

                    if (!clientResponse.IsSuccessStatusCode)
                        return NotFound();

                    Client? client = JsonConvert.DeserializeObject<Client>(clientResponse.Content ?? string.Empty);

                    RestResponse LivroResponse = ExecuteRequest($"{_livroApi}{Livro.Id}", null, Method.Get);

                    if (!clientResponse.IsSuccessStatusCode)
                        return NotFound();

                    Livro? _Livro = JsonConvert.DeserializeObject<Livro>(LivroResponse.Content ?? string.Empty);

                    object data = new
                    {
                        id = Livro.Id,
                        name = Livro.Title,
                        preco = Livro.Preco,
                        clientid = _Livro != null ? _Livro.ClientId : Livro.ClientId
                    };

                    RestResponse response = ExecuteRequest($"{_livroApi}{id}", data, Method.Put);

                    if (!response.IsSuccessful)
                        throw new Exception();
                }
                catch (Exception)
                {
                    if (!LivroExists(Livro.Id))
                        return NotFound();
                    else
                        throw;
                }
                return RedirectToAction(nameof(Index));
            }
            return View("LivroEdit", Livro);
        }

        private bool LivroExists(long id)
        {
            Livro? Livro = null;

            var response = ExecuteRequest($"{_livroApi}{id}", null, Method.Get);

            if (response.IsSuccessStatusCode)
            {
                Livro? LivroJson = JsonConvert.
                    DeserializeObject<Livro>(response.Content ?? "");

                Livro = LivroJson;
            }

            return Livro != null;
        }

        private RestResponse ExecuteRequest(string url, object? data, Method method)
        {
            RestClient restLivro = new RestClient(url);

            RestRequest request = new RestRequest()
            {
                RequestFormat = DataFormat.Json,
                Method = method
            };

            request.AddHeader("content-type", "application/json");

            if (method == Method.Post || method == Method.Put)
                request.AddBody(data);

            return restLivro.Execute(request);
        }
    }
}