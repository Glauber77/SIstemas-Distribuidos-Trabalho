﻿using Microsoft.EntityFrameworkCore;

namespace ClientAPI.Data
{
    public class EscolheLivrosContext : DbContext
    {
        public EscolheLivrosContext (DbContextOptions<EscolheLivrosContext> options)
            : base(options)
        {
        }

        public DbSet<ClientAPI.Client> Client { get; set; } = default!;
    }
}