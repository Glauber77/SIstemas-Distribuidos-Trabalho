﻿namespace ClientAPI
{
	public class Client
	{
		public long? Id { get; set; }

		public string? Name { get; set; }

		public int Age { get; set; }
	}
}