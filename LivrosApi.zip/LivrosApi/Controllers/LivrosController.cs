﻿using LivrosAPI.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LivrosAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LivrosController : ControllerBase
    {
        private readonly EscolheLivrosContext _context;

        public LivrosController(EscolheLivrosContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Livro>>> GetLivro()
        {
            return await _context.Livro.ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Livro>> GetLivro(long id)
        {
            var Livro = await _context.Livro.FindAsync(id);

            if (Livro == null)
                return NotFound();

            return Livro;
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutLivro(long id, Livro Livro)
        {
            if (id != Livro.Id)
                return BadRequest();

            _context.Entry(Livro).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!LivroExists(id))
                    return NotFound();
                else
                    throw;
            }

            return NoContent();
        }

        [HttpPost]
        public async Task<ActionResult<Livro>> PostLivro(Livro Livro)
        {
            _context.Livro.Add(Livro);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetLivro", new { id = Livro.Id }, Livro);
        }

        private bool LivroExists(long id)
        {
            return _context.Livro.Any(e => e.Id == id);
        }
    }
}