﻿using Microsoft.EntityFrameworkCore;

namespace LivrosAPI.Data
{
    public class EscolheLivrosContext : DbContext
    {
        public EscolheLivrosContext (DbContextOptions<EscolheLivrosContext> options)
            : base(options)
        {
        }

        public DbSet<LivrosAPI.Livro> Livro { get; set; } = default!;
    }
}
